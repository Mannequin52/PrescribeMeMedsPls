﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Biblioteka_AS
{
    public partial class Provjera : Form
    {

        public Provjera(List<KnjigaClass> theList)
        {
            InitializeComponent();
            foreach (KnjigaClass e in knjigaList)
            {
                provjeraText.Text += e.Ime + e.Naziv + e.Godina + e.Isbn + e.Izdavac + Environment.NewLine;
            }
        }

        private void spremiBtn_Click(object sender, EventArgs e)
        {

            KnjigaClass upisknjige = new KnjigaClass(autorimetxt.Text, nazivknjigetxt.Text, isbntxt.Text, izdavactxt.Text, Convert.ToInt32(godinatxt.Text));
            knjigaList.Add(upisknjige);
        }

        private void provjeraText_TextChanged(object sender, EventArgs e)
        {
            string ispis = autorime.Text + "\n" + nazivknjigetxt.Text + "\n" + isbntxt.Text + "\n"  +  izdavactxt.Text + "\n" + Convert.ToInt32(godinatxt.Text);
            ispis.Append(provjeraText);
        }
    }
}
