﻿namespace Biblioteka_AS
{
    partial class Provjera
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.provjeraText = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.spremiBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // provjeraText
            // 
            this.provjeraText.Location = new System.Drawing.Point(12, 86);
            this.provjeraText.Name = "provjeraText";
            this.provjeraText.Size = new System.Drawing.Size(430, 282);
            this.provjeraText.TabIndex = 0;
            this.provjeraText.Text = "";
            this.provjeraText.TextChanged += new System.EventHandler(this.provjeraText_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(134, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(179, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Jeste li sigurni da želite ovo spremiti?";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(367, 402);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Natrag";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // spremiBtn
            // 
            this.spremiBtn.Location = new System.Drawing.Point(286, 402);
            this.spremiBtn.Name = "spremiBtn";
            this.spremiBtn.Size = new System.Drawing.Size(75, 23);
            this.spremiBtn.TabIndex = 3;
            this.spremiBtn.Text = "Spremi";
            this.spremiBtn.UseVisualStyleBackColor = true;
            this.spremiBtn.Click += new System.EventHandler(this.spremiBtn_Click);
            // 
            // Provjera
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(454, 450);
            this.Controls.Add(this.spremiBtn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.provjeraText);
            this.Name = "Provjera";
            this.Text = "Provjera upisa";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox provjeraText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button spremiBtn;
    }
}